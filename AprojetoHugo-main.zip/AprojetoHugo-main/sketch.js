var nave1,nave2;
var obstacle1,obstacle2;
var fuel,life;
var star;
var nave1Img,obstacle1Img,obstacle2Img;
var starImg,fuelImg;
var backgroundImg;
var edges;
var obstacles;

function preload() {
nave1Img = loadImage("imagens/nave.png");
obstacle1Img = loadImage("imagens/meteoro.png");
obstacle2Img = loadImage("imagens/satelite.png");
starImg = loadImage("imagens/estrela.png");
fuelImg = loadImage("imagens/gasolina.png");
backgroundImg = loadImage("imagens/background.gif");
}

function setup() {
  createCanvas(windowWidth,windowHeight);

  edges = createEdgeSprites();
  
  obstacles = new Group();
   
  nave1 = createSprite(650,580,20,20);
  nave1.addImage("nave1",nave1Img)
  nave1.scale = 0.17;
}

function draw() {
 background("red");
 image(backgroundImg,0,0,width,height);
console.log("pos x "+nave1.x+"pos y "+nave1.y);

if(keyIsDown(UP_ARROW)){
    nave1.position.y -=5;
}

if(keyIsDown(RIGHT_ARROW)){
    nave1.position.x +=5;

}if(keyIsDown(LEFT_ARROW)){
    nave1.position.x -=5;
}

spawnObstacles();

nave1.bounceOff(edges);

 drawSprites();
}
function spawnObstacles() {
 //criar o srpite dos obstáculos
 if (frameCount%50==0){

 obstacle1 = createSprite(Math.round(random(40,1280)),Math.round(random(43,580)));
 obstacle1.addImage(obstacle1Img);
 obstacle1.scale = 0.15;
 obstacle1.velocityY = 3;
 obstacle1.lifetime = 550;

obstacles.add(obstacle1);
 }

//criar ou modificar a função para gerar obstáculos com diferentes imagens através do switch
 
}